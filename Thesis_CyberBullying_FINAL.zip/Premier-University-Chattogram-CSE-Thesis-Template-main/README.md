# Premier University Chattogram — CSE BSc Thesis Report Template

A LaTeX template for **BSc undergraduate thesis reports** in the Department of Computer Science and Engineering, Premier University Chattogram.

---

## Acknowledgment

Special thanks to **Noortaz Rezoana**, Lecturer, Department of CSE, Premier University Chattogram, for her contribution and assistance in developing this template.

---

## File Structure


| File / Folder | Description |
|---|---|
| `main.tex` | Main file — compile this to build the full thesis |
| `thesis.sty` | Department style file defining layout and formatting |
| `title_page.tex` | Thesis title page |
| `author_declaration.tex` | Author declaration page |
| `signature.tex` | Supervisor and examiner signature page |
| `dedication.tex` | Dedication page |
| `abstract.tex` | Thesis abstract |
| `references.bib` | BibTeX database for all references |
| `puc_logo.png` | Premier University Chattogram official logo |
| `chapters/introduction.tex` | Chapter 1 — Introduction |
| `chapters/literature_review.tex` | Chapter 2 — Literature Review |
| `chapters/methodology.tex` | Chapter 3 — Methodology |
| `chapters/results.tex` | Chapter 4 — Results and Discussion |
| `chapters/conclusion.tex` | Chapter 5 — Conclusion |
| `chapters/future_work.tex` | Chapter 6 — Future Work |

---

## Download from GitHub

**Option 1 — Download ZIP (no Git required)**

1. Go to `https://github.com/asif-saad/Premier-University-Chattogram-CSE-Thesis-Template`
2. Click the green **Code** button at the top right
3. Click **Download ZIP**
4. Extract the ZIP to a folder on your computer

**Option 2 — Clone with Git**

```bash
git clone https://github.com/asif-saad/Premier-University-Chattogram-CSE-Thesis-Template.git
```

---

## Import into Overleaf

1. Download the repository as a ZIP using the steps above
2. Go to [https://www.overleaf.com](https://www.overleaf.com) and log in or create an account
3. On your dashboard, click **New Project** → **Upload Project**
4. Select the downloaded ZIP file
5. Overleaf will unpack the project and load all files
6. Open `main.tex` from the file tree on the left
7. Click **Recompile** to generate the thesis PDF

---

## Getting Started

1. Open `main.tex` and fill in your thesis title, name, student ID, supervisor name, and session
2. Edit the front matter files with your own content:
   - `title_page.tex` — title, author, supervisor, department, year
   - `author_declaration.tex` — your signed declaration
   - `signature.tex` — supervisor and committee signatures
   - `dedication.tex` — your dedication message
   - `abstract.tex` — a concise summary of your thesis
3. Write your chapter content inside `chapters/` in order:
   - `introduction.tex` → `literature_review.tex` → `methodology.tex` → `results.tex` → `conclusion.tex` → `future_work.tex`
4. Add all references to `references.bib` in BibTeX format and cite using `\cite{key}` in the text
5. Place figures in the project root or a subfolder and insert using `\includegraphics`
6. Recompile `main.tex` at least twice to correctly generate the table of contents and bibliography

---

## License

For academic use by BSc students of the Department of CSE, Premier University Chattogram.  
Please retain acknowledgment to this repository and its contributors when sharing or adapting.
